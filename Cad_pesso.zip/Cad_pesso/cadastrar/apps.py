from django.apps import AppConfig


class CadastrarConfig(AppConfig):
    name = 'cadastrar'
